

public class SP_Manager {
	SP_CampingPitchList campingPitchList;
	
	public SP_Manager()
	{
		campingPitchList = new SP_CampingPitchList();
	}
	
	
	public void displayCampingPitchDetails()
	{	
		
		campingPitchList.PopulateCampsitePitches();
		
		System.out.format("%-15s%-20s%-15s%-15s",
			    "Pitch Number", "Owners Initials", "Cost", "Number of Beds \n");
		
		for (SP_CampingPitch pitch : campingPitchList.pitchList) {
			System.out.format("%-15d%-20s%-15f%-15d", pitch.pitchNumber, pitch.getOwnerInitials() , pitch.getCost(), pitch.getTotalNumberOfBeds());
			System.out.println("\n");
		}

	}
	
	public SP_CampingPitch getCampingPitchObject(int iPitchNum)
	{
		SP_CampingPitch pitch;
		pitch = campingPitchList.pitchList.get(iPitchNum-1);
		return pitch;
	}
	
	public String getFullDetailsOfCampingPitch(int lPitchNumber)
	{
		String strPitchDetails;
		SP_CampingPitch pitch = getCampingPitchObject(lPitchNumber);
		strPitchDetails = pitch.getFullDetails();		
		return strPitchDetails;
	}
	
	public double getMaximumIncomePerNight()
	{
		double dIncome = 0.0;		
		for (SP_CampingPitch pitch : campingPitchList.pitchList) {
			dIncome += pitch.getCost();
		}
		return dIncome;
	}
	
	//This method loops through the PitchList and gets the cost of the cheapest pitch
	public double getCostOfCheapestPitch()
	{
		double dCheapestPitchCost = 0.0;
		double dCurrentPitchCost;
		int iTemp = 1;
		for (SP_CampingPitch pitch : campingPitchList.pitchList) {
			dCurrentPitchCost= pitch.getCost();
			if (iTemp ==1)
			{
				dCheapestPitchCost = dCurrentPitchCost;
				iTemp++;
			}
				
			if(dCheapestPitchCost > dCurrentPitchCost)
				dCheapestPitchCost = dCurrentPitchCost;
		}
		return dCheapestPitchCost;
	}
	
	//This method loops through the PitchList and gets the cost of most expensive pitch   
	public double getCostOfMostExpensivePitch()
	{
		double dExpensivePitchCost = 0.0;
		double dCurrentPitchCost;
		for (SP_CampingPitch pitch : campingPitchList.pitchList) {
			dCurrentPitchCost= pitch.getCost();				
			if(dExpensivePitchCost < dCurrentPitchCost)
				dExpensivePitchCost = dCurrentPitchCost;
		}
		return dExpensivePitchCost;
	}
	
	//This method gets the total numbers of pitches available at campsite
	public int getNumberOfPitchesinCampsite()
	{
		return campingPitchList.pitchList.size();
	}
	
	public String getFrequencyReport()
	{
		String strFrequencyReport;
				
		int iCaravanCampingCount=0;
		int iNearToSeaPitchCount =0;
		int iWithAwningCount =0;
		int iWithNearbyToiletsAndShowersCount =0;
		int iInternetConnectionAvailableCount =0;
		//Gets the count of pitches provided with each of the facilities
		for (SP_CampingPitch pitch : campingPitchList.pitchList) {
			if(pitch.bCaravanCamping == true)
				iCaravanCampingCount++;
			if(pitch.bNearToSeaPitch == true)
				iNearToSeaPitchCount++;
			if(pitch.bWithAwning == true)
				iWithAwningCount++;
			if(pitch.bWithNearbyToiletsAndShowers == true)
				iWithNearbyToiletsAndShowersCount++;
			if(pitch.bInternetConnectionAvailable == true)
				iInternetConnectionAvailableCount++;
		}
		
		strFrequencyReport = "\nThe Frequency report of Facilities provided : ";
		strFrequencyReport += "\nThe number of pitches supporting Caravan Camping : " + iCaravanCampingCount;
		strFrequencyReport += "\nThe number of pitches Near to Sea : " + iNearToSeaPitchCount;
		strFrequencyReport += "\nThe number of pitches provided with Awning : " + iWithAwningCount;
		strFrequencyReport += "\nThe number of pitches near to Toilets and showers: " + iWithNearbyToiletsAndShowersCount;
		strFrequencyReport += "\nThe number of pitches provided with internet connection : " + 	iInternetConnectionAvailableCount;	
		strFrequencyReport +="\n";
				
		return strFrequencyReport;		
	}

}
