
public class SP_OwnerName {
	String firstName;
	String surName;
	public SP_OwnerName(String FName, String Surname)
	{
		firstName = FName;
		surName = Surname;
	}
	
	public String getFullName()
	{
		return firstName + ' ' + surName;
	}
	
	public String getInitials()
	{
		String strInitials;
		strInitials = firstName.substring(0,1) + "." + surName.substring(0, 1);
		strInitials.toUpperCase();
		return strInitials;
	}
}
