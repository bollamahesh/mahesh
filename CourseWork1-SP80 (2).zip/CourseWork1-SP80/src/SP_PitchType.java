
public enum SP_PitchType {
	StandardPitch,
	ElectricPitch,
	HardstandingPitch,
	ElectricAndHardstandingPitch
}
