
public class SP_CampingPitch {
	long pitchNumber;
	SP_OwnerName pitchOwner;
	SP_PitchType ePitchType;
	
	public int[] numOfBed; //space available to fit in these many number of beds-- since beds are not included in pitches  
	
	// facilities provided
	public boolean bCaravanCamping;
	public boolean bNearToSeaPitch;
	public boolean bWithAwning;
	public boolean bWithNearbyToiletsAndShowers;
	public boolean bInternetConnectionAvailable;

	public SP_CampingPitch(SP_OwnerName ownerName, long lNumber, SP_PitchType eType)
	{
		pitchOwner = ownerName;
		pitchNumber = lNumber;
		ePitchType = eType;		
	}
	
	//getCost calculates the cost of the camping pitch considering various factors of the pitch
	public double getCost()
	{
		double dPitchCost =0.00;
		//Basic cost is decided by the type of pitch chosen by the customers.
		switch(ePitchType)
		{
		case StandardPitch: 
			dPitchCost = 30.05;
			break;
		case ElectricPitch:
			dPitchCost = 55.35;
			break;
		case HardstandingPitch:
			dPitchCost = 50.30;
			break;
		case ElectricAndHardstandingPitch:
			dPitchCost = 75.40;
			break;
		}
		
		//Cost gets effected based on the type of amenities and facilities provided.  
		if(bCaravanCamping)
		{
			dPitchCost += 20.50;
		}
		if(bNearToSeaPitch)
		{
			dPitchCost += 20.00;
		}
		if(bWithAwning)
		{
			dPitchCost += 15.50;
		}
		if(bWithNearbyToiletsAndShowers)
		{
			dPitchCost +=8.50;
		}
		if(bInternetConnectionAvailable)	
		{
			dPitchCost += 5.00;
		}
		
		//Cost increases with increase in area of the pitch. 
		//This area is proportional to the number of beds that can fit into the pitch area.
		int iTotalBedCount = getTotalNumberOfBeds();
		int iRoomCount = numOfBed.length;
		double dCostOfBedSpace = (iTotalBedCount * 2.50) + (iRoomCount * 3);
		dPitchCost +=dCostOfBedSpace; 
		
		return dPitchCost;
	}
	
	public String getFullDetails()
	{
		String strFullDetails;
		
		strFullDetails = "Pitch Number	: " + pitchNumber + "\n";
		strFullDetails += "Owner Name		:  " + pitchOwner.getFullName() + "\n";
		strFullDetails += "Pitch Type 		: " + ePitchType + "\n";
		strFullDetails += "Number of Beds per room: {";
		for(int i=0; i<numOfBed.length; i++)
		{
			if (i!= 0)
				strFullDetails += ",";
			  
			strFullDetails += numOfBed[i] + " ";
		}
		
		strFullDetails +="} \n";
		
		strFullDetails += "Facilities	: ";
		if (bCaravanCamping)
			strFullDetails +="	Caravan Camping Pitch \n";
		else
			strFullDetails +="	Tent Camping Pitch \n";
		
		if(bWithAwning)
			strFullDetails +="	Awning included \n";
		
		if (bNearToSeaPitch)
			strFullDetails +="	Camping Pitch Near To Sea \n";	
		
		if (bInternetConnectionAvailable)
			strFullDetails +="	Internet connection available \n";	
		
		if(bWithNearbyToiletsAndShowers)
			strFullDetails +="	Toiles and Showers available close to Pitch \n";	
		
		double dcost = getCost();
		strFullDetails +="Pitch Rent per day	:  " + dcost ;
		strFullDetails +=" \n";
		
		return strFullDetails;
	}
	
	//This method returns Short details of the CampingPitch
	public String getShortDetails()
	{
		String strShortDetails;
				
		strShortDetails ="\nShort Details of Camping Pitch are below : ";
		strShortDetails +="\nPitch Number : " + pitchNumber; 		
		strShortDetails += "\nOwner Name 	:  " + getOwnerInitials();		
		strShortDetails += "\nTotal number of Beds :  " + getTotalNumberOfBeds();		
		strShortDetails += "\nPitch Rent per day (24 hrs) :   %.2f" + getCost();		
		
		return strShortDetails;
	}
	
	// This method sums the number of beds in each room to get the total number of beds allowed in a pitch
	public int getTotalNumberOfBeds()
	{
		int iTotalBedCount =0;
		// Loops through the numOfBeds array and sums beds from all the rooms
		for (int i= 0; i < numOfBed.length ; i++)
		{ 
			iTotalBedCount += numOfBed[i];
		}
		return iTotalBedCount;
	}
	
	//This method gets the initials of the owner
	public String getOwnerInitials()
	{
		String strInitials;
		strInitials = pitchOwner.getInitials();
		return strInitials;
	}
}
