import java.util.*;

public class SP_Campsite_Main {
	
	public static void main(String args[])
	{				
		SP_Manager manager = new SP_Manager();
		manager.displayCampingPitchDetails();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Pitch Number of your preference");
		int iPitchNumber=sc.nextInt();
		sc.close();
		
		SP_CampingPitch pitch;
		pitch = manager.getCampingPitchObject(iPitchNumber);
		pitch.getFullDetails();
		
		double CheapestCost = manager.getCostOfCheapestPitch();
		double expensive = manager.getCostOfMostExpensivePitch();
		String strDetails = manager.getFullDetailsOfCampingPitch(iPitchNumber);
		int length = manager.getNumberOfPitchesinCampsite();
		double income = manager.getMaximumIncomePerNight();
		String Report =manager.getFrequencyReport();
		
		pitch.getShortDetails();
	}
	

}
