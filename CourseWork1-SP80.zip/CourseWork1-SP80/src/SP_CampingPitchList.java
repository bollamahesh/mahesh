
import java.util.*;

public class SP_CampingPitchList {
	
	/*List<SP_CampingPitch> CampingPitchList;
	public SP_CampingPitchList()
	{
		CampingPitchList = new ArrayList<SP_CampingPitch>();		
	}*/
	 
	 public static List<SP_CampingPitch> PopulateCampsitePitches()
	{
		
		List<SP_CampingPitch> CampingPitchList = new ArrayList<SP_CampingPitch>();
		
		SP_CampingPitch CP;
		CP = new SP_CampingPitch("Harry", 1, SP_PitchType.StandardPitch);
		CP.bCaravanCamping = false;
		CP.bNearToSeaPitch = false;
		CP.bWithAwning = false;
		CP.numOfBed = new int[1];
		CP.numOfBed[0] = 2;
		CampingPitchList.add(CP);	
		
		
		SP_CampingPitch CP2 = new SP_CampingPitch("James", 2, SP_PitchType.StandardPitch);
		CP2.bCaravanCamping = false;
		CP2.bNearToSeaPitch = false;
		CP2.bWithAwning = true;
		CP2.numOfBed = new int[2];
		CP2.numOfBed[0] = 2;
		CP2.numOfBed[1] = 2;
		//CP2.getFullDetails();
		CampingPitchList.add(CP2);
		
		SP_CampingPitch CP3 = new SP_CampingPitch("jacob", 3, SP_PitchType.ElectricPitch);
		CP3.bCaravanCamping = false;
		CP3.bNearToSeaPitch = true;
		CP3.bWithAwning = false;
		CP3.numOfBed = new int[2];
		CP3.numOfBed[0] = 1;
		CP3.numOfBed[1] = 1;
		//CP3.getFullDetails();
		CampingPitchList.add(CP3);
		
		SP_CampingPitch CP4 = new SP_CampingPitch("reamus", 4, SP_PitchType.HardstandingPitch);
		CP4.bCaravanCamping = false;
		CP4.bNearToSeaPitch = true;
		CP4.bWithAwning = true;
		CP4.numOfBed = new int[2];
		CP4.numOfBed[0] = 2;
		CP4.numOfBed[1] = 1;
		//CP4.getFullDetails();
		CampingPitchList.add(CP4);
		
		SP_CampingPitch CP5 = new SP_CampingPitch("arthur", 5, SP_PitchType.ElectricPitch);
		CP5.bCaravanCamping = true;
		CP5.bNearToSeaPitch = false;
		CP5.bWithAwning = false;
		CP5.numOfBed = new int[3];
		CP5.numOfBed[0] = 2;
		CP5.numOfBed[1] = 1;
		CP5.numOfBed[2] = 2;
		//CP5.getFullDetails();
		CampingPitchList.add(CP5);
		
		SP_CampingPitch CP6 = new SP_CampingPitch("Molly", 6, SP_PitchType.HardstandingPitch);
		CP6.bCaravanCamping = true;
		CP6.bNearToSeaPitch = false;
		CP6.bWithAwning = false;
		CP6.numOfBed = new int[3];
		CP6.numOfBed[0] = 2;
		CP6.numOfBed[1] = 1;
		CP6.numOfBed[2] = 1;
		//CP6.getFullDetails();
		CampingPitchList.add(CP6);
		
		SP_CampingPitch CP7 = new SP_CampingPitch("Lilly", 7, SP_PitchType.ElectricAndHardstandingPitch);
		CP7.bCaravanCamping = true;
		CP7.bNearToSeaPitch = false;
		CP7.bWithAwning = true;
		CP7.numOfBed = new int[2];
		CP7.numOfBed[0] = 2;
		CP7.numOfBed[1] = 1;
		//CP7.getFullDetails();
		CampingPitchList.add(CP7);
		
		SP_CampingPitch CP8 = new SP_CampingPitch("yara", 8, SP_PitchType.ElectricAndHardstandingPitch);
		CP8.bCaravanCamping = true;
		CP8.bNearToSeaPitch = true;
		CP8.bWithAwning = true;
		CP8.numOfBed = new int[2];
		CP8.numOfBed[0] = 2;
		CP8.numOfBed[1] = 1;
		//CP8.getFullDetails();
		CampingPitchList.add(CP8);
		
		SP_CampingPitch CP9 = new SP_CampingPitch("emma", 9, SP_PitchType.ElectricAndHardstandingPitch);
		CP9.bCaravanCamping = true;
		CP9.bNearToSeaPitch = true;
		CP9.bWithAwning = true;
		CP9.numOfBed = new int[3];
		CP9.numOfBed[0] = 2;
		CP9.numOfBed[1] = 2;
		CP9.numOfBed[2] = 3;
		//CP9.getFullDetails();
		CampingPitchList.add(CP9);
		
		return CampingPitchList;
		
	}
}
