
public class SP_CampingPitch {
	String strPitchOwner;
	long lPitchNumber;
	SP_PitchType ePitchType;
	public int[] numOfBed; //need to explain -- bed allowance 
	
	// facilities
	public boolean bCaravanCamping;
	public boolean bNearToSeaPitch;
	public boolean bWithAwning;

	public SP_CampingPitch(String strOwner, long lNumber, SP_PitchType eType)
	{
		strPitchOwner = strOwner;
		lPitchNumber = lNumber;
		ePitchType = eType;		
	}
	
	public double getCost()
	{
		double dPitchCost =0.00;
		switch(ePitchType)
		{
		case StandardPitch: 
			dPitchCost = 40.05;
			break;
		case ElectricPitch:
			dPitchCost = 55.35;
			break;
		case HardstandingPitch:
			dPitchCost = 50.30;
			break;
		case ElectricAndHardstandingPitch:
			dPitchCost = 75.40;
			break;
		}
		
		if(bCaravanCamping)
		{
			dPitchCost += 20.50;
		}
		if(bNearToSeaPitch)
		{
			dPitchCost += 20;
		}
		if(bWithAwning)
		{
			dPitchCost += 15.50;
		}
		
		return dPitchCost;
	}
	
	public void getFullDetails()
	{
		System.out.println("Pitch Number		: " + lPitchNumber ); 
		System.out.println("Owner Name		:  " + strPitchOwner);
		System.out.println("Pitch Type 		: " + ePitchType );
		
		System.out.print("Num of beds per room	: { ");
		for(int i=0; i<numOfBed.length; i++)
		{
			if (i!= 0)
				System.out.print(",");
			  
			System.out.print(numOfBed[i] + " ");
		}
		
		System.out.print("} \n");
		
		System.out.println("Facilities 		: ");
		if (bCaravanCamping)
			System.out.println("	Caravan Camping Pitch ");
		else
			System.out.println("	Tent camping pitch");
		
		if(bWithAwning)
			System.out.println("	Awning included ");
		
		if (bNearToSeaPitch)
			System.out.println("	Camping Pitch Near To Sea ");	
		
		double dcost = getCost();
		System.out.println("Pitch Rent per day	:  " + dcost );
		System.out.println(" \n");
	}
	
	public void getShortDetails()
	{
		System.out.println("\nShort Details of Camping Pitch are below : ");
		System.out.println("Pitch Number : " + lPitchNumber ); 

		double dCost = getCost();
		
		System.out.println("Pitch Rent per day (24 hrs) :   %.2f" + dCost );
		
		System.out.println("Owner Name :  " + strPitchOwner);
	}
	
	public int getTotalNumberOfBeds()
	{
		int totalBedCount =0;
		
		for (int i= 0; i < numOfBed.length ; i++)
		{ 
			totalBedCount += numOfBed[i];
		}
		return totalBedCount;
	}
}
