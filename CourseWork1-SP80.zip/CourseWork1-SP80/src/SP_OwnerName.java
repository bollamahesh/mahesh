
public class SP_OwnerName {
	String strFirstName;
	String strSurName;
	public SP_OwnerName(String FName, String Surname)
	{
		strFirstName = FName;
		strSurName = Surname;
	}
	
	public String GetFullName()
	{
		return strFirstName + ' ' + strSurName;
	}
	
	public String GetInitials()
	{
		String strInitials;
		strInitials = strFirstName.substring(0,1) + " . " + strSurName.substring(0, 1);
		strInitials.toUpperCase();
		return strInitials;
	}
}
