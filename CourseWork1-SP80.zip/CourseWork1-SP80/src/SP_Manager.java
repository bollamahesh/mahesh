import java.util.List;

public class SP_Manager {
	List<SP_CampingPitch> PitchList;
	public void DisplayCampingPitchDetails()
	{	
		PitchList = SP_CampingPitchList.PopulateCampsitePitches();
		
		System.out.format("%-15s%-20s%-15s%-15s",
			    "Pitch Number", "Owners Initials", "Cost", "Number of Beds \n");
		
		SP_CampingPitch Pitch = PitchList.get(0);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(1);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(2);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(3);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(4);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(5);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(6);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(7);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		System.out.println("\n");
		Pitch = PitchList.get(8);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		
		/*System.out.println("\n");
		Pitch = PitchList.get(9);
		System.out.format("%-15d%-20s%-15f%-15d", Pitch.lPitchNumber, "S P", Pitch.getCost(), Pitch.getTotalNumberOfBeds());
		*/		
	}
	
	public SP_CampingPitch GetCampingPitchObject(int iPitchNum)
	{
		SP_CampingPitch Pitch;
		Pitch = PitchList.get(iPitchNum-1);
		return Pitch;
	}
	

}
